// Love Chat Server - Node.js + Express + Socket.io
// Install dependencies: npm install express socket.io axios cors

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const axios = require('axios');
const cors = require('cors');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: '*',
        methods: ['GET', 'POST']
    }
});

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// In-memory storage
const rooms = new Map();
const users = new Map();
const aiChats = new Map();

// MiniMax API Configuration
const MINIMAX_API_URL = 'https://api.minimax.chat/v1/text/chatcompletion_v2';
const DEFAULT_SYSTEM_PROMPT = `You are a charming, warm, and affectionate dating companion.
Speak in a friendly, flirty, and caring manner.
Make the user feel special and valued.
Keep responses conversational, heartfelt, and use appropriate emojis.
Be romantic, attentive, and caring.`;

// ============ Socket.io Real-time Chat ============
io.on('connection', (socket) => {
    console.log(`User connected: ${socket.id}`);

    // Create Room
    socket.on('createRoom', ({ userName, roomCode }) => {
        const room = {
            code: roomCode,
            host: socket.id,
            users: new Map([[socket.id, { id: socket.id, name: userName, isHost: true }]]),
            messages: [],
            createdAt: new Date()
        };
        rooms.set(roomCode, room);
        socket.join(roomCode);
        users.set(socket.id, { roomCode, userName });

        socket.emit('roomCreated', {
            roomCode,
            users: Array.from(room.users.values())
        });

        console.log(`Room created: ${roomCode} by ${userName}`);
    });

    // Join Room
    socket.on('joinRoom', ({ userName, roomCode }) => {
        const room = rooms.get(roomCode);

        if (!room) {
            socket.emit('error', { message: 'Room not found!' });
            return;
        }

        room.users.set(socket.id, { id: socket.id, name: userName, isHost: false });
        socket.join(roomCode);
        users.set(socket.id, { roomCode, userName });

        // Notify user joined
        const joinMessage = {
            type: 'system',
            content: `${userName} joined the chat!`,
            timestamp: new Date()
        };
        room.messages.push(joinMessage);

        socket.emit('roomJoined', {
            roomCode,
            users: Array.from(room.users.values()),
            messages: room.messages.slice(-50)
        });

        socket.to(roomCode).emit('userJoined', {
            user: { id: socket.id, name: userName, isHost: false },
            message: joinMessage
        });

        console.log(`${userName} joined room ${roomCode}`);
    });

    // Send Message
    socket.on('sendMessage', ({ content, roomCode }) => {
        const room = rooms.get(roomCode);
        if (!room) return;

        const userInfo = room.users.get(socket.id);
        if (!userInfo) return;

        const message = {
            type: 'chat',
            sender: userInfo.name,
            senderId: socket.id,
            content,
            timestamp: new Date()
        };
        room.messages.push(message);

        io.to(roomCode).emit('newMessage', message);
    });

    // Private Message
    socket.on('privateMessage', ({ toUserId, content, roomCode }) => {
        const room = rooms.get(roomCode);
        if (!room) return;

        const userInfo = room.users.get(socket.id);
        const targetUser = room.users.get(toUserId);

        if (userInfo && targetUser) {
            const message = {
                type: 'private',
                sender: userInfo.name,
                senderId: socket.id,
                to: targetUser.name,
                toId: toUserId,
                content,
                timestamp: new Date()
            };

            socket.to(toUserId).emit('privateMessage', message);
            socket.emit('privateMessage', message);
        }
    });

    // Handle Disconnect
    socket.on('disconnect', () => {
        const userData = users.get(socket.id);
        if (userData) {
            const room = rooms.get(userData.roomCode);
            if (room) {
                const userInfo = room.users.get(socket.id);
                if (userInfo) {
                    room.users.delete(socket.id);

                    const leaveMessage = {
                        type: 'system',
                        content: `${userInfo.name} left the chat`,
                        timestamp: new Date()
                    };
                    room.messages.push(leaveMessage);

                    socket.to(userData.roomCode).emit('userLeft', {
                        userId: socket.id,
                        userName: userInfo.name,
                        message: leaveMessage,
                        users: Array.from(room.users.values())
                    });

                    // Delete room if empty
                    if (room.users.size === 0) {
                        rooms.delete(userData.roomCode);
                        console.log(`Room ${userData.roomCode} deleted (empty)`);
                    }
                }
            }
            users.delete(socket.id);
        }
        console.log(`User disconnected: ${socket.id}`);
    });
});

// ============ REST API Endpoints ============

// AI Chat Endpoint (MiniMax)
app.post('/api/ai/chat', async (req, res) => {
    const { messages, systemPrompt, apiKey } = req.body;

    if (!apiKey) {
        return res.status(400).json({ error: 'API key required' });
    }

    try {
        const response = await axios.post(
            MINIMAX_API_URL,
            {
                model: 'abab6.5s-chat',
                messages: [
                    { role: 'system', content: systemPrompt || DEFAULT_SYSTEM_PROMPT },
                    ...messages.slice(-10).map(m => ({
                        role: m.role === 'user' ? 'user' : 'assistant',
                        content: m.content
                    }))
                ],
                temperature: 0.8,
                max_tokens: 300
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                }
            }
        );

        // MiniMax API response parsing
        console.log('MiniMax Response:', JSON.stringify(response.data).substring(0, 200));

        // MiniMax response format: { base_resp: {...}, choices: [{ message: { content: "..." } }] }
        const reply = response.data?.choices?.[0]?.message?.content ||
                      response.data?.choices?.[0]?.content ||
                      response.data?.choices?.[0]?.text ||
                      'Sorry, I had trouble responding. Could you try again?';

        res.json({ reply });
    } catch (error) {
        console.error('MiniMax API Error:', error.response?.data || error.message);
        res.status(500).json({
            error: 'AI service error',
            message: error.response?.data?.error?.message || error.message
        });
    }
});

// Get room info
app.get('/api/room/:code', (req, res) => {
    const room = rooms.get(req.params.code);
    if (!room) {
        return res.status(404).json({ error: 'Room not found' });
    }
    res.json({
        code: room.code,
        users: Array.from(room.users.values()),
        messageCount: room.messages.length
    });
});

// Get room list (public rooms)
app.get('/api/rooms', (req, res) => {
    const publicRooms = [];
    rooms.forEach((room, code) => {
        if (room.users.size > 0) {
            publicRooms.push({
                code,
                userCount: room.users.size,
                createdAt: room.createdAt
            });
        }
    });
    res.json(publicRooms);
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        uptime: process.uptime(),
        rooms: rooms.size,
        users: users.size
    });
});

// ============ Start Server ============
const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════╗
║         Love Chat Server Running        ║
╠════════════════════════════════════════╣
║  🌐 Server: http://localhost:${PORT}       ║
║  📡 WebSocket: ws://localhost:${PORT}       ║
║  🔗 API: http://localhost:${PORT}/api       ║
╠════════════════════════════════════════╣
║  Features:                              ║
║  • Real-time multi-user chat            ║
║  • Room management (create/join)       ║
║  • Private messaging                    ║
║  • MiniMax AI integration               ║
╚════════════════════════════════════════╝
    `);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\nShutting down server...');
    io.close();
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});
